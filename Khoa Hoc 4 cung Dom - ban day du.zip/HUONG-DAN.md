# HƯỚNG DẪN DÙNG — Khoa Học 4 cùng Đóm          ✅ BẢN NHÁP

**Mở:** bấm đúp `Khoa Hoc 4 cung Dom.html` (Edge hoặc Chrome). Không cần mạng. Giữ file `Dom Dom Lab.html` **cùng thư mục** để nút «Mô phỏng» ở Bài 8 mở được.

**Ở lớp (chiếu TV):** Góc của cô → «📺 Chữ to khi chiếu TV». Đầu tiết: mở «3 điều cần nhớ» của bài trước, cả lớp đọc to. Cuối tiết: chơi trò chơi của bài, HS lên bấm theo lượt. Cuối chủ đề: «Ôn tập chủ đề» → Đấu trường 10 câu, cả lớp giơ thẻ A/B/C/D.

**Ở nhà (HS tự học):** mỗi ngày 10 phút: mở «🔁 Ôn hôm nay» làm các câu đến hạn, rồi học bài mới.

**Sửa nội dung:** nội dung từng bài nằm ở `_nguon/du-lieu-c1.js` … `du-lieu-c6.js` (mỗi file một chủ đề). Sửa xong chạy `python _nguon/ghep.py` để ghép lại. Hoặc nhắn em: «Bài 5 câu 2 đổi thành …».

**Dữ liệu:** nằm trong trình duyệt **của máy đó**. Xoá lịch sử duyệt web hoặc đổi máy sẽ mất nếu chưa sao lưu → thứ Sáu vào Góc của cô bấm «💾 Sao lưu».

**Giọng đọc:** nút 🔊 đọc bằng giọng tiếng Việt có sẵn trong máy; máy không có giọng Việt sẽ báo, không đọc sai bằng giọng Anh.
